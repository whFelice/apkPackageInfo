#include <iostream>
#include "apkinfo.h"
using namespace std;

int main()
{
    apkinfo* apk = new apkinfo("a.apk");
    apk->dumpInfo();
    delete(apk); //new֮��ǵ�delete�ͷ��ڴ�
    system("pause > nul");
    return 0;
}
