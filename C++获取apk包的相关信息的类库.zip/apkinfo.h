#ifndef __APK_INFO__
#define __APK_INFO__

#include <iostream>
#include <windows.h>
#include <string>
#include "strHandle.h"
#include "strRW.h"
using namespace std;
class apkinfo{
    public:
        string packageName;             //����
        string versionCode;             //versionCode
        string versionName;             //�汾��
        string sdkVersion;              //sdk�汾
        string targetSdkVersion;        //Ŀ��sdk�汾
        string appName;                 //app����
        string appName_Zh_CN;           //app����(����)
        string launchableActivity;      //��ʾ�������ϵ�ͼ����������activity����
        string iconPath;                //appͼ���ڰ��е�·��


        apkinfo(string apkPath){
            getPackageInfo(apkPath);
            parsePackageInfo();
        }

        void dumpInfo(){
            cout << " - " << appName << endl
                 << " - " << appName_Zh_CN << endl
                 << " - " << packageName << endl
                 << " - " << versionCode << endl
                 << " - " << versionName << endl
                 << " - " << sdkVersion << endl
                 << " - " << targetSdkVersion << endl
                 << " - " << launchableActivity << endl
                 << " - " << iconPath << endl
                 ;
        }
    private:
        void getPackageInfo(string apkPath){
            //tools\bin\aapt.exe d badging "Ŀ��apk�ļ�" > tools\apkinfo\info
            string cmd = "";
            cmd = "tools\\bin\\aapt.exe d badging \"" + apkPath + "\" > tools\\apkinfo\\info";
            //cout<<cmd<<endl;
            system(cmd.c_str());
        }
        void parsePackageInfo(){
            string infoText = readStr("tools\\apkinfo\\info");
            string_replace(infoText, " ","");
            packageName         = getMiddleStr(infoText,"package:name='","'");
            versionCode         = getMiddleStr(infoText,"versionCode='","'");
            versionName         = getMiddleStr(infoText,"versionName='","'");
            sdkVersion          = getMiddleStr(infoText,"sdkVersion:'","'");
            targetSdkVersion    = getMiddleStr(infoText,"targetSdkVersion:'","'");
            appName             = getMiddleStr(infoText,"application-label:'","'");
            appName_Zh_CN       = getMiddleStr(infoText,"application-label-zh_CN:'","'");
            launchableActivity  = getMiddleStr(infoText,"launchable-activity:name='","'");
            iconPath            = getMiddleStr(infoText,"icon='","'");
        }

};

#endif // __APK_INFO_HEAD__
